#ifndef H_readBarcodeLoad
#define H_readBarcodeLoad

#include "IncludeDefine.h"
#include "Parameters.h"

void loadBarcodeRead(Parameters &P, istream **readInStream, string &seq1, string &qual1);

#endif
