#ifndef CODE_systemFunctions
#include <string>

std::string linuxProcMemory();

#endif
