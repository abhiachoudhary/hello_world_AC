#include "Transcript.h"

void Transcript::variationOutput(Variation &Var)
{
    //
};
