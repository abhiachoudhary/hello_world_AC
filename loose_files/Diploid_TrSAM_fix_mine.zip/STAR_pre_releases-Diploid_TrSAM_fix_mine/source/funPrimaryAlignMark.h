#include "ReadAlign.h"
//#include "Transcript.h"
//#include "Parameters.h"

void funPrimaryAlignMark(Transcript **trMult, uint64 nTr, Parameters &P, int maxScore, std::uniform_real_distribution<double> rngUniformReal0to1, std::mt19937 rngMultOrder);