#ifndef CODE_genomeScanFastaFiles
#define CODE_genomeScanFastaFiles

#include "Parameters.h"
#include "IncludeDefine.h"
#include "Genome.h"

uint genomeScanFastaFiles (Parameters &P, char* G, bool flagRun, Genome &mapGen);

#endif
